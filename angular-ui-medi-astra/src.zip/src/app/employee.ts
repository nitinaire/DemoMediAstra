export class Employee {
    id: number;
    firstName: string;
    lastName: string;
    emailId: string;
	employeeID:string;
	bloodGroup:string;
	isIntake:string;
	vacAddress:string;
    active: boolean;
	city:string;
}