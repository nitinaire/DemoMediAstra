export class FileDB {
    name: string;
	reason: string;
	fileName: string;
}