export class HelpingHand {
    id: number;
    name: string;
    reason: string;
}