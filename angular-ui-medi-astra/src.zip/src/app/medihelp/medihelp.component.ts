import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medihelp',
  templateUrl: './medihelp.component.html',
  styleUrls: ['./medihelp.component.css']
})
export class MedihelpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
